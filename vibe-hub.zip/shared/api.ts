/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

export interface ItemDTO {
  id: string;
  name: string;
  parent: string;
  category: string;
  subcategory: string;
  description: string;
  slowMovingPromo: boolean;
  fiberVendor: string;
  itemSubstitutes?: string;
}

export interface ItemsResponse {
  items: ItemDTO[];
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  categories: string[];
  subcategoriesAll: string[];
  subcategoriesByCategory: Record<string, string[]>;
  fiberVendorsByCategory: Record<string, string[]>;
}

export interface ItemInsights {
  id: string;
  pricingRecommendations: { note: string; date?: string }[];
  priceHistory: { date: string; price: number; currency?: string }[];
  purchaseOrders: {
    date: string;
    vendor?: string;
    cost: number;
    currency?: string;
    qty?: number;
  }[];
  leadTimes: { vendor?: string; avgDays: number; lastUpdated?: string }[];
}

export interface ItemAvailabilityRow {
  location: string;
  available: number;
  lastUpdated?: string;
}

export interface ItemAvailabilityResponse {
  id: string;
  availability: ItemAvailabilityRow[];
}

export interface SalesRecord {
  salesOrder: string;
  dateCreated: string; // ISO YYYY-MM-DD
  client: string;
  market: string;
  quantity: number;
  unitPrice: number;
  estUnitCost: number;
  estGrossProfitPct: number;
  markUpPct: number;
  terms: string;
}

export interface SalesResponse {
  records: SalesRecord[];
  total: number;
  page: number;
  limit: number;
}

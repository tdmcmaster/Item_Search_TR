import { ReactNode } from "react";
import { Link } from "react-router-dom";

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-10 border-b bg-white dark:bg-background">
        <div className="container flex h-14 items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-semibold">
            <span className="inline-flex h-6 w-6 items-center justify-center rounded-md bg-blue-600 text-white">
              IS
            </span>
            <span>Item Search</span>
          </Link>
        </div>
      </header>
      <main className="container py-6 md:py-8">{children}</main>
      <footer className="border-t py-6 text-center text-sm text-muted-foreground">
        <div className="container">
          © {new Date().getFullYear()} Item Search
        </div>
      </footer>
    </div>
  );
}

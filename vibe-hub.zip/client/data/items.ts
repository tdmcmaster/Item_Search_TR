export type Item = {
  id: string;
  name: string;
  parent: string;
  category: string; // Top-level category
  subcategory: string; // Sub-category
  description: string;
};

export const ITEMS: Item[] = [
  {
    id: "ITM001",
    name: "Wireless Bluetooth Headphones",
    parent: "Electronics",
    category: "Audio",
    subcategory: "Headphones",
    description:
      "High-quality wireless headphones with noise cancellation and 30-hour battery life.",
  },
  {
    id: "ITM002",
    name: "Gaming Mechanical Keyboard",
    parent: "Electronics",
    category: "Computer",
    subcategory: "Keyboards",
    description:
      "RGB backlit mechanical keyboard with cherry MX switches for gaming and productivity.",
  },
  {
    id: "ITM003",
    name: "Smartphone Case",
    parent: "Accessories",
    category: "Mobile",
    subcategory: "Cases",
    description:
      "Durable protective case with reinforced corners and screen protection.",
  },
  {
    id: "ITM004",
    name: "Laptop Stand",
    parent: "Office Supplies",
    category: "Ergonomics",
    subcategory: "Stands",
    description:
      "Adjustable aluminum laptop stand for improved posture and cooling.",
  },
  {
    id: "ITM005",
    name: "Coffee Maker",
    parent: "Kitchen",
    category: "Appliances",
    subcategory: "Coffee",
    description:
      "Programmable drip coffee maker with thermal carafe and auto-brew timer.",
  },
  {
    id: "ITM006",
    name: "Fitness Tracker",
    parent: "Health",
    category: "Wearables",
    subcategory: "Fitness",
    description:
      "Waterproof fitness tracker with heart rate monitoring and GPS tracking.",
  },
  {
    id: "ITM007",
    name: "Desk Lamp",
    parent: "Office Supplies",
    category: "Lighting",
    subcategory: "Task Lighting",
    description:
      "LED desk lamp with adjustable brightness and color temperature settings.",
  },
  {
    id: "ITM008",
    name: "Wireless Mouse",
    parent: "Electronics",
    category: "Computer",
    subcategory: "Mice",
    description:
      "Ergonomic wireless mouse with precision optical sensor and long battery life.",
  },
];

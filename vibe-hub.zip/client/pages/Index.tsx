import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import Layout from "@/components/Layout";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Search, Badge, LayoutGrid, Table as TableIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import type { ItemDTO, ItemsResponse } from "@shared/api";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationPrevious,
  PaginationNext,
  PaginationLink,
} from "@/components/ui/pagination";
import { Button } from "@/components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import {
  Table,
  TableHeader,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from "@/components/ui/table";

const CARD_PAGE_SIZE = 100;
const TABLE_PAGE_SIZE = 50;

export default function Index() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [viewMode, setViewMode] = useState<"cards" | "table">(() =>
    searchParams.get("view") === "table" ? "table" : "cards",
  );
  const [query, setQuery] = useState(() => searchParams.get("q") ?? "");
  const [category, setCategory] = useState<string>(
    () => searchParams.get("category") ?? "all",
  );
  const [sub, setSub] = useState<string>(
    () => searchParams.get("sub") ?? "all",
  );
  const [promo, setPromo] = useState<"all" | "yes" | "no">(
    () => (searchParams.get("promo") as any) || "all",
  );
  const [vendor, setVendor] = useState<string>(
    () => searchParams.get("vendor") ?? "all",
  );
  const [page, setPage] = useState<number>(() => {
    const p = Number(searchParams.get("page") || 1);
    return Number.isFinite(p) && p > 0 ? Math.floor(p) : 1;
  });
  const pageSize = viewMode === "table" ? TABLE_PAGE_SIZE : CARD_PAGE_SIZE;

  // Keep URL in sync with filters for back/forward persistence (non-destructive; preserve unknown params)
  useEffect(() => {
    const p = new URLSearchParams(searchParams);
    const qTrim = query.trim();
    if (qTrim) p.set("q", qTrim);
    else p.delete("q");
    if (category && category !== "all") p.set("category", category);
    else p.delete("category");
    if (sub && sub !== "all") p.set("sub", sub);
    else p.delete("sub");
    if (promo && promo !== "all") p.set("promo", promo);
    else p.delete("promo");
    if (category === "500 - Cable & Wire" && vendor && vendor !== "all")
      p.set("vendor", vendor);
    else p.delete("vendor");
    if (page > 1) p.set("page", String(page));
    else p.delete("page");
    if (viewMode !== "cards") p.set("view", viewMode);
    else p.delete("view");
    const next = p.toString();
    const curr = searchParams.toString();
    if (next !== curr) setSearchParams(p, { replace: true });
  }, [
    query,
    category,
    sub,
    promo,
    vendor,
    page,
    viewMode,
    searchParams,
    setSearchParams,
  ]);

  const { data, isLoading, error } = useQuery({
    queryKey: [
      "items",
      pageSize,
      page,
      query,
      category,
      sub,
      promo,
      vendor,
      viewMode,
    ],
    queryFn: async (): Promise<ItemsResponse> => {
      const params = new URLSearchParams({
        limit: String(pageSize),
        page: String(page),
      });
      if (query.trim()) params.set("q", query.trim());
      if (category && category !== "all") params.set("category", category);
      if (sub && sub !== "all") params.set("sub", sub);
      if (promo && promo !== "all") params.set("promo", promo);
      if (category === "500 - Cable & Wire" && vendor && vendor !== "all")
        params.set("vendor", vendor);
      let res: Response;
      try {
        // Try the conventional API path first, then fall back to Netlify function path which is used in some deploy contexts
        const tryUrls = [
          `/api/items?${params.toString()}`,
          `/.netlify/functions/api/items?${params.toString()}`,
        ];
        let lastErr: any = null;
        for (const url of tryUrls) {
          try {
            res = await fetch(url);
            // If fetch succeeded but returned network-level 0 response, keep lastErr
            if (res) {
              lastErr = null;
              break;
            }
          } catch (err) {
            lastErr = err;
            console.warn("/api/items fetch attempt failed for", url, err);
            continue;
          }
        }
        if (!res && lastErr) throw lastErr;
      } catch (err) {
        // Network error (DNS, CORS, connection reset, etc.) — recover with empty response
        console.error("/api/items fetch failed:", err);
        return {
          items: [],
          page,
          limit: pageSize,
          total: 0,
          totalPages: 1,
          categories: [],
          subcategoriesAll: [],
          subcategoriesByCategory: {},
          fiberVendorsByCategory: {},
        } as ItemsResponse;
      }

      if (!res.ok) {
        let msg = `HTTP ${res.status}`;
        try {
          const text = await res.clone().text();
          if (text) msg += ` ${text}`;
        } catch {}
        throw new Error(msg);
      }
      return res.json();
    },
    keepPreviousData: true,
    staleTime: 5 * 60_000,
    gcTime: 15 * 60_000,
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  const items = data?.items ?? [];
  const total = data?.total ?? undefined;
  const totalPages = data?.totalPages ?? undefined;

  const categories = useMemo(() => {
    return data?.categories ?? [];
  }, [data]);

  const subcategories = useMemo(() => {
    if (!data) return [];
    if (category === "all") return data.subcategoriesAll ?? [];
    return data.subcategoriesByCategory?.[category] ?? [];
  }, [category, data]);

  const fiberVendors = useMemo(() => {
    if (!data) return [] as string[];
    if (category !== "500 - Cable & Wire") return [] as string[];
    return data.fiberVendorsByCategory?.[category] ?? [];
  }, [category, data]);

  const [createOpen, setCreateOpen] = useState(false);
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [approvalOpen, setApprovalOpen] = useState(false);

  const [newParent, setNewParent] = useState("");
  const [newManufacturer, setNewManufacturer] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newItemId, setNewItemId] = useState("");
  const [newJustification, setNewJustification] = useState("");

  const [qQty, setQQty] = useState<number | "">("");
  const [qCost, setQCost] = useState<number | "">("");
  const [qUnit, setQUnit] = useState<number | "">("");
  const [approvalNotes, setApprovalNotes] = useState("");

  function genNextId() {
    // Derive numeric prefix from existing item IDs in view: prefer xxx-xxx-xxx, else xxx-xxx, else 000-000
    const scan = (filtered && filtered.length ? filtered : items) || [];
    let part1 = "000";
    let part2 = "000";
    for (const it of scan) {
      const id = String(it.id || "").trim();
      const m =
        id.match(/^(\d{3})-(\d{3})(?:-(\d{3}))?$/) ||
        id.match(/^(\d{3})-(\d{3})\b/);
      if (m) {
        part1 = m[1];
        part2 = m[2];
        break;
      }
    }
    const prefix = `${part1}-${part2}`;

    // Find next numeric suffix within same prefix
    let maxSuffix = 0;
    for (const it of scan) {
      const id = String(it.id || "").trim();
      const mm = id.match(new RegExp(`^${prefix}-(\\d{3})$`));
      if (mm) {
        const n = parseInt(mm[1], 10);
        if (Number.isFinite(n) && n > maxSuffix) maxSuffix = n;
      }
    }
    const next = String(Math.min(999, maxSuffix + 1)).padStart(3, "0");
    return `${prefix}-${next}`;
  }

  function resetCreateFlow() {
    setCreateOpen(false);
    setQuoteOpen(false);
    setApprovalOpen(false);
    setNewParent("");
    setNewManufacturer("");
    setNewDescription("");
    setNewItemId("");
    setNewJustification("");
    setQQty("");
    setQCost("");
    setQUnit("");
    setApprovalNotes("");
  }

  const hasSearched = useMemo(() => {
    return (
      query.trim().length > 0 ||
      category !== "all" ||
      sub !== "all" ||
      promo !== "all" ||
      (category === "500 - Cable & Wire" && vendor !== "all")
    );
  }, [query, category, sub, promo, vendor]);

  const filterSummary = useMemo(() => {
    const parts: string[] = [];
    const q = query.trim();
    if (q) parts.push(`Query: "${q}"`);
    if (category !== "all") parts.push(`Category: ${category}`);
    if (sub !== "all") parts.push(`Sub: ${sub}`);
    if (promo !== "all") parts.push(`SMI: ${promo === "yes" ? "Yes" : "No"}`);
    if (category === "500 - Cable & Wire" && vendor !== "all")
      parts.push(`Vendor: ${vendor}`);
    return parts.join(" · ");
  }, [query, category, sub, promo, vendor]);

  const canCreateNew = useMemo(
    () => category !== "all" && sub !== "all",
    [category, sub],
  );

  // Auto-assign next ID when opening create modal
  useEffect(() => {
    if (createOpen && !newItemId) {
      try {
        setNewItemId(genNextId());
      } catch {}
    }
  }, [createOpen]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((i) => {
      const text =
        `${i.name} ${i.description} ${i.id} ${i.parent} ${i.category} ${i.subcategory} ${i.fiberVendor} ${i.itemSubstitutes || ""} ${i.slowMovingPromo ? "yes" : "no"}`.toLowerCase();
      const tokens = q
        ? Array.from(q.matchAll(/"([^"]+)"|(\S+)/g))
            .map((m) => (m[1] || m[2] || "").toLowerCase())
            .filter(Boolean)
        : [];
      const matchesQ =
        tokens.length === 0 || tokens.every((t) => text.includes(t));
      const matchesCat = category === "all" || i.category === category;
      const matchesSub = sub === "all" || i.subcategory === sub;
      const matchesPromo =
        promo === "all" ||
        (promo === "yes" ? i.slowMovingPromo : !i.slowMovingPromo);
      const matchesVendor =
        category !== "500 - Cable & Wire" ||
        vendor === "all" ||
        (i.category === "500 - Cable & Wire" && i.fiberVendor === vendor);
      return (
        matchesQ && matchesCat && matchesSub && matchesPromo && matchesVendor
      );
    });
  }, [query, category, sub, promo, vendor, items]);

  return (
    <Layout>
      <div className="space-y-4">
        <h1 className="text-sm font-medium text-muted-foreground">
          Item Search
        </h1>

        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(1);
            }}
            placeholder="Search items..."
            className="pl-9 h-11"
            aria-label="Search items"
          />
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          Tips: Type multiple words to match all across item fields. Use quotes
          for exact phrases (e.g., "Fusion Splicer Kit"). Fields searched: ID,
          Name, Parent, Category, Subcategory, Description, SMI (yes/no), Fiber
          Vendor, Item Substitutes.
        </p>

        <div className="flex flex-wrap gap-3 rounded-lg border p-3 md:p-4">
          <FilterLabel>Category:</FilterLabel>
          <Select
            value={category}
            onValueChange={(v) => {
              setCategory(v);
              setSub("all");
              if (v !== "500 - Cable & Wire") setVendor("all");
              setPage(1);
            }}
          >
            <SelectTrigger className="w-48 h-9">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <FilterLabel>Sub Category:</FilterLabel>
          <Select
            value={sub}
            onValueChange={(v) => {
              setSub(v);
              setPage(1);
            }}
          >
            <SelectTrigger className="w-56 h-9">
              <SelectValue placeholder="All Sub Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sub Categories</SelectItem>
              {subcategories.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {category === "500 - Cable & Wire" && (
            <>
              <FilterLabel>Fiber Vendor:</FilterLabel>
              <Select
                value={vendor}
                onValueChange={(v) => {
                  setVendor(v);
                  setPage(1);
                }}
              >
                <SelectTrigger className="w-56 h-9">
                  <SelectValue placeholder="All Vendors" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Vendors</SelectItem>
                  {fiberVendors.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </>
          )}

          <p className="inline-flex items-center text-sm text-muted-foreground">
            SMI
          </p>
          <Select
            value={promo}
            onValueChange={(v) => {
              setPromo(v as any);
              setPage(1);
            }}
          >
            <SelectTrigger className="w-40 h-9">
              <SelectValue placeholder="All" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="yes">Yes</SelectItem>
              <SelectItem value="no">No</SelectItem>
            </SelectContent>
          </Select>

          <div className="ml-auto flex items-center gap-2">
            <FilterLabel>View:</FilterLabel>
            <ViewToggle
              value={viewMode}
              onChange={(v) => {
                if (v) {
                  setViewMode(v);
                  setPage(1);
                }
              }}
            />
            <Button
              variant="secondary"
              className="h-9"
              onClick={() => {
                setQuery("");
                setCategory("all");
                setSub("all");
                setPage(1);
                setPromo("all");
                setVendor("all");
              }}
            >
              Clear filters
            </Button>
          </div>
        </div>

        {hasSearched && (
          <div className="rounded-lg border bg-card p-3 md:p-4 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <Input
                readOnly
                value={filterSummary || "No filters"}
                className="bg-muted/40"
                aria-label="Current filters"
              />
            </div>
            {canCreateNew && (
              <Button className="md:ml-3" onClick={() => setCreateOpen(true)}>
                Create New Item
              </Button>
            )}
          </div>
        )}

        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Item</DialogTitle>
            </DialogHeader>
            <div className="grid gap-3">
              <div className="grid gap-1 text-xs">
                <div className="font-medium">Filters</div>
                <div className="text-muted-foreground break-words">
                  {filterSummary || "No filters"}
                </div>
                <div className="text-muted-foreground/80">
                  Filters will be used for this new item.
                </div>
              </div>
              <div className="grid gap-2 md:grid-cols-2">
                <div className="grid gap-2">
                  <Label htmlFor="new-parent">Parent</Label>
                  <Input
                    id="new-parent"
                    value={newParent}
                    onChange={(e) => setNewParent(e.target.value)}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="new-mfg">Manufacturer</Label>
                  <Input
                    id="new-mfg"
                    value={newManufacturer}
                    onChange={(e) => setNewManufacturer(e.target.value)}
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="new-desc">Item Description</Label>
                <textarea
                  id="new-desc"
                  className="min-h-32 h-36 w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="new-id">New Item ID</Label>
                <Input
                  id="new-id"
                  value={newItemId}
                  onChange={(e) => setNewItemId(e.target.value)}
                  placeholder="Auto-assigned"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="new-just">Justification</Label>
                <textarea
                  id="new-just"
                  className="min-h-32 h-36 w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  placeholder="Provide details on why you are adding this Item"
                  value={newJustification}
                  onChange={(e) => setNewJustification(e.target.value)}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Click "Send To Purchasing" if you are requesting a new item to
                be added to catalog. Click "Create and Submit" if you need to
                create the item for a Quote. This will create a placeholder Item
                and submit the item for approval.
              </p>
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  variant="secondary"
                  type="button"
                  onClick={() => {
                    if (!newItemId) setNewItemId(genNextId());
                    if (!approvalNotes && newJustification.trim())
                      setApprovalNotes(newJustification.trim());
                    setCreateOpen(false);
                    setQuoteOpen(false);
                    setApprovalOpen(true);
                  }}
                >
                  Send To Purchasing
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    if (!newItemId) setNewItemId(genNextId());
                    if (!approvalNotes && newJustification.trim())
                      setApprovalNotes(newJustification.trim());
                    setCreateOpen(false);
                    setQuoteOpen(true);
                  }}
                >
                  Create and Submit
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={quoteOpen} onOpenChange={setQuoteOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add to Estimate</DialogTitle>
            </DialogHeader>
            <div className="grid gap-3">
              <div className="grid gap-2">
                <Label htmlFor="q-item">Item ID</Label>
                <Input id="q-item" readOnly value={newItemId} />
              </div>
              <div className="grid gap-2 md:grid-cols-3">
                <div className="grid gap-2">
                  <Label htmlFor="q-qty">Quantity</Label>
                  <Input
                    id="q-qty"
                    type="number"
                    min={0}
                    value={qQty}
                    onChange={(e) =>
                      setQQty(
                        e.target.value === "" ? "" : Number(e.target.value),
                      )
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="q-cost">Cost</Label>
                  <Input
                    id="q-cost"
                    type="number"
                    min={0}
                    step="0.01"
                    value={qCost}
                    onChange={(e) =>
                      setQCost(
                        e.target.value === "" ? "" : Number(e.target.value),
                      )
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="q-unit">Unit Price</Label>
                  <Input
                    id="q-unit"
                    type="number"
                    min={0}
                    step="0.01"
                    value={qUnit}
                    onChange={(e) =>
                      setQUnit(
                        e.target.value === "" ? "" : Number(e.target.value),
                      )
                    }
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  onClick={() => {
                    setQuoteOpen(false);
                    setApprovalOpen(true);
                  }}
                >
                  Add
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={approvalOpen} onOpenChange={setApprovalOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Approval Notes / Justification</DialogTitle>
            </DialogHeader>
            <div className="grid gap-3 text-sm">
              <div className="grid gap-2">
                <div className="font-medium">Review</div>
                <div className="grid gap-2">
                  <div className="grid gap-1">
                    <span className="text-muted-foreground/70">Item ID</span>
                    <div className="rounded-md border bg-muted/30 px-3 py-2">
                      {newItemId}
                    </div>
                  </div>
                  {newParent.trim() && (
                    <div className="grid gap-1">
                      <span className="text-muted-foreground/70">Parent</span>
                      <div className="rounded-md border bg-muted/30 px-3 py-2">
                        {newParent}
                      </div>
                    </div>
                  )}
                  {newManufacturer.trim() && (
                    <div className="grid gap-1">
                      <span className="text-muted-foreground/70">
                        Manufacturer
                      </span>
                      <div className="rounded-md border bg-muted/30 px-3 py-2">
                        {newManufacturer}
                      </div>
                    </div>
                  )}
                  {newDescription.trim() && (
                    <div className="grid gap-1">
                      <span className="text-muted-foreground/70">
                        Item Description
                      </span>
                      <div className="rounded-md border bg-muted/30 px-3 py-2 whitespace-pre-wrap">
                        {newDescription}
                      </div>
                    </div>
                  )}
                  {(approvalNotes.trim() || newJustification.trim()) && (
                    <div className="grid gap-1">
                      <span className="text-muted-foreground/70">
                        Justification
                      </span>
                      <div className="rounded-md border bg-muted/30 px-3 py-2 whitespace-pre-wrap">
                        {approvalNotes || newJustification}
                      </div>
                    </div>
                  )}
                  {(qQty !== "" || qCost !== "" || qUnit !== "") && (
                    <div className="grid gap-2 md:grid-cols-3">
                      {qQty !== "" && (
                        <div className="grid gap-1">
                          <span className="text-muted-foreground/70">
                            Quantity
                          </span>
                          <div className="rounded-md border bg-muted/30 px-3 py-2">
                            {String(qQty)}
                          </div>
                        </div>
                      )}
                      {qCost !== "" && (
                        <div className="grid gap-1">
                          <span className="text-muted-foreground/70">Cost</span>
                          <div className="rounded-md border bg-muted/30 px-3 py-2">
                            {String(qCost)}
                          </div>
                        </div>
                      )}
                      {qUnit !== "" && (
                        <div className="grid gap-1">
                          <span className="text-muted-foreground/70">
                            Unit Price
                          </span>
                          <div className="rounded-md border bg-muted/30 px-3 py-2">
                            {String(qUnit)}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  onClick={() => {
                    resetCreateFlow();
                  }}
                >
                  Submit
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {isLoading && (
          <div className="text-sm text-muted-foreground">Loading items…</div>
        )}
        {error && (
          <div className="text-sm text-red-600 break-words">
            Failed to load items.{" "}
            {error instanceof Error ? error.message : String(error)}
          </div>
        )}

        {typeof total === "number" && (
          <div className="text-xs text-muted-foreground">
            Showing {Math.min((page - 1) * pageSize + 1, Math.max(total, 0))}–
            {Math.min(page * pageSize, Math.max(total, 0))} of {total}
          </div>
        )}

        <div className="pb-2">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setPage((p) => Math.max(1, p - 1));
                  }}
                  className={cn("", {
                    "pointer-events-none opacity-50": page <= 1,
                  })}
                />
              </PaginationItem>
              <PaginationItem>
                <PaginationLink href="#" isActive>
                  {page}
                </PaginationLink>
              </PaginationItem>
              <PaginationItem>
                <PaginationNext
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setPage((p) =>
                      totalPages ? Math.min(totalPages, p + 1) : p + 1,
                    );
                  }}
                  className={cn("", {
                    "pointer-events-none opacity-50": Boolean(
                      totalPages && page >= totalPages,
                    ),
                  })}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>

        {viewMode === "cards" ? (
          <div className="grid items-stretch gap-4 md:gap-5 grid-cols-1 sm:grid-cols-2 xl:grid-cols-3">
            {filtered.map((item) => (
              <ItemCard
                key={item.id}
                item={item}
                linkSearch={searchParams.toString()}
              />
            ))}
            {filtered.length === 0 && !isLoading && (
              <div className="col-span-full text-center text-muted-foreground py-10">
                No results.
              </div>
            )}
          </div>
        ) : (
          <div className="rounded-lg border bg-card">
            <ItemsTable
              items={filtered}
              showVendor={category === "500 - Cable & Wire"}
              linkSearch={searchParams.toString()}
            />
            {filtered.length === 0 && !isLoading && (
              <div className="text-center text-muted-foreground py-10">
                No results.
              </div>
            )}
          </div>
        )}

        <div className="pt-4">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setPage((p) => Math.max(1, p - 1));
                  }}
                  className={cn("", {
                    "pointer-events-none opacity-50": page <= 1,
                  })}
                />
              </PaginationItem>
              <PaginationItem>
                <PaginationLink href="#" isActive>
                  {page}
                </PaginationLink>
              </PaginationItem>
              <PaginationItem>
                <PaginationNext
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setPage((p) =>
                      totalPages ? Math.min(totalPages, p + 1) : p + 1,
                    );
                  }}
                  className={cn("", {
                    "pointer-events-none opacity-50": Boolean(
                      totalPages && page >= totalPages,
                    ),
                  })}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      </div>
    </Layout>
  );
}

function ViewToggle({
  value,
  onChange,
}: {
  value: "cards" | "table";
  onChange: (v: "cards" | "table" | "") => void;
}) {
  return (
    <div className="inline-flex items-center gap-1">
      <ToggleGroup
        type="single"
        value={value}
        onValueChange={onChange}
        aria-label="Select view mode"
      >
        <ToggleGroupItem
          value="cards"
          aria-label="Cards view"
          className="h-9 px-3"
        >
          <LayoutGrid className="h-4 w-4" />
          <span className="ml-2 hidden sm:inline">Cards</span>
        </ToggleGroupItem>
        <ToggleGroupItem
          value="table"
          aria-label="Table view"
          className="h-9 px-3"
        >
          <TableIcon className="h-4 w-4" />
          <span className="ml-2 hidden sm:inline">Table</span>
        </ToggleGroupItem>
      </ToggleGroup>
    </div>
  );
}

function ItemsTable({
  items,
  showVendor,
  linkSearch,
}: {
  items: ItemDTO[];
  showVendor: boolean;
  linkSearch?: string;
}) {
  const showSubs = useMemo(
    () => items.some((i) => (i.itemSubstitutes || "").trim().length > 0),
    [items],
  );
  return (
    <Table className="text-xs">
      <TableHeader>
        <TableRow>
          <TableHead className="w-[140px]">Item ID</TableHead>
          <TableHead>Name</TableHead>
          <TableHead className="w-[160px]">Parent</TableHead>
          <TableHead className="w-[220px]">Category</TableHead>
          {showVendor && (
            <TableHead className="w-[200px]">Fiber Vendor</TableHead>
          )}
          {showSubs && <TableHead className="w-[220px]">Substitutes</TableHead>}
        </TableRow>
      </TableHeader>
      <TableBody>
        {items.map((i) => (
          <TableRow key={i.id}>
            <TableCell className="font-medium tabular-nums text-blue-600">
              <Link
                className="text-blue-600 hover:underline"
                to={`/items/${encodeURIComponent(i.id)}${linkSearch ? `?${linkSearch}` : ""}`}
              >
                {i.id}
              </Link>
            </TableCell>
            <TableCell className="align-top max-w-[28rem]">
              <div className="font-medium truncate">
                <Link
                  className="text-blue-600 hover:underline"
                  title={i.name}
                  to={`/items/${encodeURIComponent(i.id)}${linkSearch ? `?${linkSearch}` : ""}`}
                >
                  {i.name}
                </Link>
              </div>
              {(i.description || "").trim() && (
                <div className="mt-1 border-t border-border/60 pt-1 text-muted-foreground whitespace-normal break-words">
                  {i.description}
                </div>
              )}
            </TableCell>
            <TableCell className="truncate max-w-[12rem]" title={i.parent}>
              {i.parent}
            </TableCell>
            <TableCell
              className="truncate max-w-[16rem]"
              title={`${i.category} / ${i.subcategory}`}
            >
              {i.category} / {i.subcategory}
            </TableCell>
            {showVendor && (
              <TableCell
                className="truncate max-w-[16rem]"
                title={i.fiberVendor}
              >
                {i.fiberVendor}
              </TableCell>
            )}
            {showSubs && (
              <TableCell
                className="truncate max-w-[20rem]"
                title={i.itemSubstitutes}
              >
                {i.itemSubstitutes}
              </TableCell>
            )}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

function FilterLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center text-sm text-muted-foreground">
      {children}
    </span>
  );
}

function ItemCard({
  item,
  linkSearch,
}: {
  item: ItemDTO;
  linkSearch?: string;
}) {
  return (
    <Card className="h-full p-4 md:p-5">
      <div className="flex gap-3">
        <div className="h-9 w-9 shrink-0 rounded-full bg-blue-50 text-blue-600 ring-1 ring-blue-200 flex items-center justify-center">
          <Badge className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="font-semibold text-sm md:text-base leading-6 md:leading-7 break-words line-clamp-2">
            <Link
              className="text-blue-600 hover:underline"
              to={`/items/${encodeURIComponent(item.id)}${linkSearch ? `?${linkSearch}` : ""}`}
            >
              {item.name}
            </Link>
          </div>
          <div className="mt-1 grid gap-x-6 gap-y-1 text-[13px] text-muted-foreground sm:grid-cols-2">
            <Meta label="Item ID" value={item.id} />
            <Meta label="Parent" value={item.parent} />
            <Meta
              label="Category"
              value={`${item.category} / ${item.subcategory}`}
              className="sm:col-span-2"
            />
            {item.category === "500 - Cable & Wire" && (
              <Meta label="Fiber Vendor" value={item.fiberVendor} />
            )}
            {(item.itemSubstitutes || "").trim() && (
              <Meta label="Item Substitutes" value={item.itemSubstitutes!} />
            )}
          </div>
          <p className="mt-2 text-sm leading-6 text-muted-foreground whitespace-pre-wrap break-words">
            {item.description}
          </p>
        </div>
      </div>
    </Card>
  );
}

function Meta({
  label,
  value,
  className,
}: {
  label: string;
  value: string;
  className?: string;
}) {
  return (
    <div className={cn("min-w-0", className)}>
      <span className="text-muted-foreground/70">{label}: </span>
      <span className="align-middle break-words whitespace-normal">
        {value}
      </span>
    </div>
  );
}

import { useParams, Link, useNavigate, useLocation } from "react-router-dom";
import Layout from "@/components/Layout";
import { useQuery } from "@tanstack/react-query";
import type {
  ItemDTO,
  ItemInsights,
  ItemAvailabilityResponse,
  SalesResponse,
} from "@shared/api";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableRow, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useMemo, useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ItemDetail() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const { data, isLoading, error } = useQuery<ItemDTO | { error: string }>({
    queryKey: ["item", id],
    enabled: Boolean(id),
    queryFn: async () => {
      const res = await fetch(`/api/items/${encodeURIComponent(id!)}`);
      if (res.status === 404) return { error: "Not found" };
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    },
    staleTime: 5 * 60_000,
    gcTime: 15 * 60_000,
  });

  const notFound = (data as any)?.error === "Not found";
  const item =
    (data as ItemDTO) && !(data as any)?.error ? (data as ItemDTO) : undefined;

  const { data: insights } = useQuery<ItemInsights>({
    queryKey: ["item-insights", id],
    enabled: Boolean(id),
    queryFn: async () => {
      try {
        const res = await fetch(
          `/api/items/${encodeURIComponent(id!)}/insights`,
        );
        if (!res.ok) throw new Error(String(res.status));
        return res.json();
      } catch {
        return {
          id: id!,
          pricingRecommendations: [],
          priceHistory: [],
          purchaseOrders: [],
          leadTimes: [],
        } as ItemInsights;
      }
    },
    staleTime: 5 * 60_000,
    gcTime: 15 * 60_000,
  });

  const { data: availability } = useQuery<ItemAvailabilityResponse>({
    queryKey: ["item-availability", id],
    enabled: Boolean(id),
    queryFn: async () => {
      try {
        const res = await fetch(
          `/api/items/${encodeURIComponent(id!)}/availability`,
        );
        if (!res.ok) throw new Error(String(res.status));
        return res.json();
      } catch {
        return { id: id!, availability: [] } as ItemAvailabilityResponse;
      }
    },
    staleTime: 5 * 60_000,
    gcTime: 15 * 60_000,
  });

  const { data: sales } = useQuery<SalesResponse>({
    queryKey: ["sales", id],
    enabled: Boolean(id),
    queryFn: async () => {
      try {
        const label = (item?.name || item?.id || id || "").trim();
        const url = new URL("/api/sales", window.location.origin);
        if (label) url.searchParams.set("item", label);
        url.searchParams.set("limit", "50");
        url.searchParams.set("days", "90");
        const res = await fetch(url.toString());
        if (!res.ok) throw new Error(String(res.status));
        return res.json();
      } catch {
        return { records: [], total: 0, page: 1, limit: 50 } as SalesResponse;
      }
    },
    staleTime: 5 * 60_000,
    gcTime: 15 * 60_000,
  });

  // Client filter (stubbed clients, deterministic per item)
  const clientOptions = useMemo(() => {
    const pool = [
      "Acme Corp",
      "Globex",
      "Soylent",
      "Initech",
      "Umbrella",
      "Hooli",
      "Vehement Capital",
      "Stark Industries",
      "Wayne Enterprises",
      "Wonka Co.",
      "Tyrell Corp",
      "Gringotts",
      "Cyberdyne",
      "Pied Piper",
      "Vandelay Industries",
      "Duff Beer",
      "Oceanic",
      "Massive Dynamic",
      "Aperture Labs",
      "Black Mesa",
    ];
    const seed =
      (id || "")
        .split("")
        .reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 0) || 42;
    const arr = [...pool];
    let s = seed;
    for (let i = arr.length - 1; i > 0; i--) {
      s = (s * 1664525 + 1013904223) >>> 0;
      const j = s % (i + 1);
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr.slice(0, 10);
  }, [id]);
  const [client, setClient] = useState<string>("all");
  const [clientOpen, setClientOpen] = useState(false);
  const clientLabel = client === "all" ? "All Clients" : client;

  const pricingByClient = useMemo(() => {
    const src = insights?.pricingRecommendations ?? [];
    const withClient = src.map((p, idx) => ({
      ...p,
      __client: clientOptions[idx % clientOptions.length],
    }));
    return client === "all"
      ? withClient
      : withClient.filter((p) => (p as any).__client === client);
  }, [insights?.pricingRecommendations, client, clientOptions]);

  const priceHistoryByClient = useMemo(() => {
    const src = insights?.priceHistory ?? [];
    const withClient = src.map((r, idx) => ({
      ...r,
      __client: clientOptions[idx % clientOptions.length],
    }));
    return client === "all"
      ? withClient
      : withClient.filter((r) => (r as any).__client === client);
  }, [insights?.priceHistory, client, clientOptions]);

  const poHistoryByClient = useMemo(() => {
    const src = insights?.purchaseOrders ?? [];
    const withClient = src.map((r, idx) => ({
      ...r,
      __client: clientOptions[idx % clientOptions.length],
    }));
    return client === "all"
      ? withClient
      : withClient.filter((r) => (r as any).__client === client);
  }, [insights?.purchaseOrders, client, clientOptions]);

  return (
    <Layout>
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            onClick={() => {
              try {
                const ref = document.referrer;
                let sameOrigin = false;
                try {
                  sameOrigin =
                    !!ref && new URL(ref).origin === window.location.origin;
                } catch {}
                if (sameOrigin && window.history.length > 1) {
                  navigate(-1);
                } else {
                  navigate(`/${location.search || ""}`);
                }
              } catch {
                navigate(`/${location.search || ""}`);
              }
            }}
          >
            Back
          </Button>
          {item && (
            <div className="text-sm text-muted-foreground">
              / items / {item.id}
            </div>
          )}
        </div>

        {isLoading && (
          <div className="text-sm text-muted-foreground">Loading…</div>
        )}
        {error && (
          <div className="text-sm text-red-600">
            Failed to load item: {String((error as any)?.message || error)}
          </div>
        )}
        {notFound && (
          <div className="text-sm text-muted-foreground">Item not found.</div>
        )}

        <Card className="p-3 md:p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="text-sm text-muted-foreground">Client:</div>
            <Popover open={clientOpen} onOpenChange={setClientOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={clientOpen}
                  className="w-64 justify-between"
                >
                  {clientLabel}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="p-0 w-72">
                <Command>
                  <CommandInput placeholder="Search client..." />
                  <CommandList>
                    <CommandEmpty>No clients found.</CommandEmpty>
                    <CommandGroup>
                      <CommandItem
                        value="all"
                        onSelect={() => {
                          setClient("all");
                          setClientOpen(false);
                        }}
                      >
                        <Check
                          className={cn(
                            "mr-2 h-4 w-4",
                            client === "all" ? "opacity-100" : "opacity-0",
                          )}
                        />
                        All Clients
                      </CommandItem>
                      {clientOptions.map((c) => (
                        <CommandItem
                          key={c}
                          value={c}
                          onSelect={() => {
                            setClient(c);
                            setClientOpen(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              client === c ? "opacity-100" : "opacity-0",
                            )}
                          />
                          {c}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>
        </Card>

        <div className="grid gap-4 lg:gap-5 grid-cols-1 xl:grid-cols-2">
          {item && (
            <Card className="p-3 md:p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="text-base md:text-lg font-semibold">
                  {item.name || item.id}
                </div>
                <div className="flex items-center gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="sm">Add to Estimate</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add to Estimate</DialogTitle>
                      </DialogHeader>
                      <div className="grid gap-4 py-2">
                        <div className="grid gap-2">
                          <Label htmlFor="quote-item-id">Item ID</Label>
                          <Input id="quote-item-id" value={item.id} readOnly />
                        </div>
                        <div className="grid gap-2 grid-cols-1 sm:grid-cols-3 sm:gap-3">
                          <div className="grid gap-2">
                            <Label htmlFor="quote-qty">Quantity</Label>
                            <Input
                              id="quote-qty"
                              type="number"
                              min={0}
                              placeholder="0"
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="quote-cost">Cost</Label>
                            <Input
                              id="quote-cost"
                              type="number"
                              min={0}
                              step="0.01"
                              placeholder="0.00"
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="quote-unit">Unit Price</Label>
                            <Input
                              id="quote-unit"
                              type="number"
                              min={0}
                              step="0.01"
                              placeholder="0.00"
                            />
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <DialogClose asChild>
                          <Button type="button">Add</Button>
                        </DialogClose>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
              <div className="mt-2 md:mt-3 grid gap-3 md:gap-4 md:grid-cols-2">
                <div>
                  <Table className="text-xs">
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium w-36 md:w-40">
                          Item ID
                        </TableCell>
                        <TableCell className="break-words">{item.id}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Parent</TableCell>
                        <TableCell className="break-words">
                          {item.parent}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Category</TableCell>
                        <TableCell className="break-words">
                          {item.category} / {item.subcategory}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">SMI</TableCell>
                        <TableCell>
                          {item.slowMovingPromo ? "Yes" : "No"}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
                <div>
                  <Table className="text-xs">
                    <TableBody>
                      {item.category === "500 - Cable & Wire" &&
                        item.fiberVendor && (
                          <TableRow>
                            <TableCell className="font-medium w-36 md:w-40">
                              Fiber Vendor
                            </TableCell>
                            <TableCell className="break-words">
                              {item.fiberVendor}
                            </TableCell>
                          </TableRow>
                        )}
                    </TableBody>
                  </Table>
                </div>

                {item.itemSubstitutes && item.itemSubstitutes.trim() && (
                  <div className="md:col-span-2">
                    <Table className="text-xs">
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium w-36 md:w-40">
                            Item Substitutes
                          </TableCell>
                          <TableCell className="break-words whitespace-pre-wrap">
                            {item.itemSubstitutes}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                )}

                {item.description && item.description.trim() && (
                  <div className="md:col-span-2">
                    <Table className="text-xs">
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium w-36 md:w-40">
                            Description
                          </TableCell>
                          <TableCell className="break-words whitespace-pre-wrap">
                            {item.description}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </Card>
          )}

          <Card className="p-3 md:p-4">
            <div className="text-base md:text-lg font-semibold">
              Pricing Recommendations
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              Client: {clientLabel}
            </div>
            <div className="mt-2">
              {pricingByClient.length ? (
                <ul className="list-disc pl-5 text-xs md:columns-2 md:gap-6 [column-fill:_balance]">
                  {pricingByClient.map((p, idx) => (
                    <li
                      key={idx}
                      className="break-words mb-1 break-inside-avoid"
                    >
                      {p.note}{" "}
                      {p.date && (
                        <Badge variant="outline" className="ml-2">
                          {p.date}
                        </Badge>
                      )}
                      <Badge variant="secondary" className="ml-2">
                        {(p as any).__client}
                      </Badge>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="text-xs text-muted-foreground">
                  No pricing recommendations available.
                </div>
              )}
            </div>
          </Card>
        </div>

        <div className="grid gap-4 lg:gap-5 grid-cols-1 lg:grid-cols-2">
          <Card className="p-3 md:p-4">
            <div className="text-base md:text-lg font-semibold">
              Price History
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              Client: {clientLabel}
            </div>
            <div className="mt-2">
              {priceHistoryByClient.length ? (
                <Table className="text-xs">
                  <TableBody>
                    {priceHistoryByClient.map((r, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="w-28 md:w-32">
                          <Badge variant="secondary">
                            {(r as any).__client}
                          </Badge>
                        </TableCell>
                        <TableCell className="w-32 md:w-40 text-muted-foreground">
                          {r.date}
                        </TableCell>
                        <TableCell className="font-medium">
                          {r.price.toLocaleString(undefined, {
                            style: "currency",
                            currency: r.currency || "USD",
                          })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-xs text-muted-foreground">
                  No price history.
                </div>
              )}
            </div>
          </Card>

          <Card className="p-3 md:p-4">
            <div className="text-base md:text-lg font-semibold">
              PO Purchase History
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              Client: {clientLabel}
            </div>
            <div className="mt-2">
              {poHistoryByClient.length ? (
                <Table className="text-xs">
                  <TableBody>
                    {poHistoryByClient.map((r, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="w-28 md:w-32">
                          <Badge variant="secondary">
                            {(r as any).__client}
                          </Badge>
                        </TableCell>
                        <TableCell className="w-24 md:w-28 text-muted-foreground">
                          {r.date}
                        </TableCell>
                        <TableCell className="w-40 md:w-48 break-words">
                          {r.vendor || ""}
                        </TableCell>
                        <TableCell className="font-medium">
                          {r.cost.toLocaleString(undefined, {
                            style: "currency",
                            currency: r.currency || "USD",
                          })}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {r.qty ? `${r.qty} pcs` : ""}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-xs text-muted-foreground">
                  No PO purchase history.
                </div>
              )}
            </div>
          </Card>

          <Card className="p-3 md:p-4">
            <div className="text-base md:text-lg font-semibold">
              Recent Sales
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              Showing last 90 days
            </div>
            <div className="mt-2">
              {sales?.records?.length ? (
                <Table className="text-xs">
                  <TableBody>
                    {sales!.records.map((r, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="w-28 md:w-32 text-muted-foreground">
                          {r.dateCreated}
                        </TableCell>
                        <TableCell className="w-28 md:w-32 break-words">
                          {r.salesOrder}
                        </TableCell>
                        <TableCell className="w-40 md:w-48 break-words">
                          {r.client}
                        </TableCell>
                        <TableCell className="w-32 md:w-40 break-words">
                          {r.market}
                        </TableCell>
                        <TableCell className="w-20 text-right">
                          {r.quantity}
                        </TableCell>
                        <TableCell className="w-28 text-right">
                          {r.unitPrice.toLocaleString(undefined, {
                            style: "currency",
                            currency: "USD",
                          })}
                        </TableCell>
                        <TableCell className="w-28 text-right">
                          {r.estUnitCost.toLocaleString(undefined, {
                            style: "currency",
                            currency: "USD",
                          })}
                        </TableCell>
                        <TableCell className="w-24 text-right text-muted-foreground">
                          {r.estGrossProfitPct}%
                        </TableCell>
                        <TableCell className="w-24 text-right text-muted-foreground">
                          {r.markUpPct}%
                        </TableCell>
                        <TableCell className="w-32 break-words">
                          {r.terms}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-xs text-muted-foreground">
                  No recent sales.
                </div>
              )}
            </div>
          </Card>

          <Card className="p-3 md:p-4">
            <div className="text-base md:text-lg font-semibold">Lead Times</div>
            <div className="mt-2">
              {insights?.leadTimes?.length ? (
                <Table className="text-xs">
                  <TableBody>
                    {insights!.leadTimes.map((r, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="w-40 md:w-48 break-words">
                          {r.vendor || ""}
                        </TableCell>
                        <TableCell className="font-medium">
                          {r.avgDays} days
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {r.lastUpdated || ""}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-xs text-muted-foreground">
                  No lead time data.
                </div>
              )}
            </div>
          </Card>

          <Card className="p-3 md:p-4">
            <div className="text-base md:text-lg font-semibold">
              Item Availability
            </div>
            <div className="mt-2">
              {availability?.availability?.length ? (
                <Table className="text-xs">
                  <TableBody>
                    {availability!.availability.map((r, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="w-48 break-words">
                          {r.location}
                        </TableCell>
                        <TableCell className="font-medium">
                          {r.available}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {r.lastUpdated || ""}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-xs text-muted-foreground">
                  No availability data.
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

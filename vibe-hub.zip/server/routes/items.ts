import type { RequestHandler } from "express";
import type { ItemDTO, ItemsResponse, ItemInsights } from "@shared/api";
import crypto from "node:crypto";
import zlib from "node:zlib";

const DOMO_BASE = process.env.DOMO_BASE_URL || "https://api.domo.com";
const SCOPE = process.env.DOMO_SCOPE || "data";

async function getAccessToken(): Promise<string> {
  const clientId = process.env.DOMO_CLIENT_ID;
  const clientSecret = process.env.DOMO_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    const missing: string[] = [];
    if (!clientId) missing.push("DOMO_CLIENT_ID");
    if (!clientSecret) missing.push("DOMO_CLIENT_SECRET");
    throw new Error(
      `DOMO credentials not configured: missing ${missing.join(", ")}`,
    );
  }

  const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    scope: SCOPE,
  });

  console.log("DOMO auth: requesting token from", `${DOMO_BASE}/oauth/token`);
  const res = await fetch(`${DOMO_BASE}/oauth/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${creds}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
  }).catch((err) => {
    console.error("DOMO auth fetch failed:", err);
    throw err;
  });

  console.log("DOMO auth response status:", res.status);
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    console.error("DOMO auth error body:", t);
    throw new Error(`DOMO auth failed: ${res.status} ${t}`);
  }
  const json = (await res.json()) as { access_token: string };
  console.log("DOMO auth success: token length", json.access_token?.length ?? 0);
  return json.access_token;
}

function normalizeKey(key: string) {
  return key
    .trim()
    .toLowerCase()
    .replace(/[\s_-]+/g, "");
}

function mapRecordToItem(rec: Record<string, unknown>): ItemDTO | null {
  const keys = Object.keys(rec);
  const nk = Object.fromEntries(keys.map((k) => [normalizeKey(k), k]));

  const pick = (candidates: string[]) => {
    for (const c of candidates) {
      const k = nk[c];
      if (k && rec[k] != null) return String(rec[k]);
    }
    return "";
  };

  const id = pick([
    normalizeKey(process.env.DOMO_COL_ID || "Item ID"),
    "id",
    "itemid",
  ]);
  const name = pick([
    normalizeKey(process.env.DOMO_COL_NAME || "Name"),
    "title",
    "itemname",
    "name",
  ]);
  const parent = pick([
    normalizeKey(process.env.DOMO_COL_PARENT || "Parent"),
    "parent",
  ]);
  const category = pick([
    normalizeKey(process.env.DOMO_COL_CATEGORY || "Category"),
    "category",
  ]);
  const subcategory = pick([
    normalizeKey(process.env.DOMO_COL_SUBCATEGORY || "Sub Category"),
    "subcategory",
    "subcat",
  ]);
  const description = pick([
    normalizeKey(process.env.DOMO_COL_DESCRIPTION || "Description"),
    "desc",
    "details",
  ]);
  const promoRaw = pick([
    normalizeKey(process.env.DOMO_COL_SLOW_PROMO || "Slow Moving Inventory Promo"),
    "slowmovinginventorypromo",
    "slowpromo",
    "promo",
  ]);
  const pr = promoRaw.trim().toLowerCase();
  const slowMovingPromo = pr === "yes" || pr === "y" || pr === "true" || pr === "1";
  const fiberVendor = pick([
    normalizeKey(process.env.DOMO_COL_FIBER_VENDOR || "Fiber Vendor"),
    "fibervendor",
    "vendor",
  ]);
  const itemSubstitutes = pick([
    normalizeKey(process.env.DOMO_COL_ITEM_SUBSTITUTES || "Item Substitutes"),
    "itemsubstitutes",
    "substitutes",
  ]);

  if (!id && !name) return null;
  return { id, name, parent, category, subcategory, description, slowMovingPromo, fiberVendor, itemSubstitutes };
}

function parseCSV(csv: string): Record<string, string>[] {
  const rows: string[][] = [];
  let i = 0;
  let field = "";
  let row: string[] = [];
  let inQuotes = false;
  while (i < csv.length) {
    const ch = csv[i];
    if (inQuotes) {
      if (ch === '"') {
        if (csv[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        } else {
          inQuotes = false;
          i++;
          continue;
        }
      } else {
        field += ch;
        i++;
        continue;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
        i++;
        continue;
      }
      if (ch === ",") {
        row.push(field);
        field = "";
        i++;
        continue;
      }
      if (ch === "\n") {
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
        i++;
        continue;
      }
      if (ch === "\r") {
        i++;
        continue;
      }
      field += ch;
      i++;
    }
  }
  row.push(field);
  rows.push(row);
  if (rows.length === 0) return [];
  const headers = rows[0];
  return rows
    .slice(1)
    .filter((r) => r.length && r.some((c) => c !== ""))
    .map((r) => {
      const obj: Record<string, string> = {};
      for (let j = 0; j < headers.length; j++) {
        obj[headers[j]] = r[j] ?? "";
      }
      return obj;
    });
}

async function fetchDataset(token: string): Promise<Record<string, unknown>[]> {
  const datasetId = process.env.DOMO_DATASET_ID;
  if (!datasetId) throw new Error("DOMO_DATASET_ID not set");

  const url = `${DOMO_BASE}/v1/datasets/${datasetId}/data?includeHeader=true&format=json`;
  console.log("DOMO data: requesting", url);
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
  }).catch((err) => {
    console.error("DOMO data fetch network error:", err);
    throw err;
  });
  console.log("DOMO data response status:", res.status);
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    console.error("DOMO data error body:", t);
    throw new Error(`DOMO data fetch failed: ${res.status} ${t}`);
  }

  const ctype = res.headers.get("content-type") || "";
  if (ctype.includes("application/json")) {
    const json = (await res.json()) as Record<string, unknown>[];
    return json;
  }
  const text = await res.text();
  const rows = parseCSV(text);
  return rows as Record<string, unknown>[];
}

// In-memory dataset cache with TTL
interface DatasetCache {
  items: ItemDTO[];
  /** sha1 of dataset content, stable across TTL window */
  hash: string;
  /** when the cache expires (epoch ms) */
  expiresAt: number;
  /** when it was fetched (epoch ms) */
  fetchedAt: number;
}
let __datasetCache: DatasetCache | null = null;

function getTTLms(): number {
  const envMin = Number(process.env.ITEMS_DATASET_TTL_MINUTES ?? 10);
  const minutes = Number.isFinite(envMin) ? Math.max(5, Math.min(15, Math.floor(envMin))) : 10;
  return minutes * 60_000;
}

async function getDatasetCached(): Promise<DatasetCache> {
  const now = Date.now();
  if (__datasetCache && __datasetCache.expiresAt > now && __datasetCache.items.length) {
    const age = now - __datasetCache.fetchedAt;
    const ttlLeft = __datasetCache.expiresAt - now;
    console.log("[items] dataset cache HIT", { count: __datasetCache.items.length, ageMs: age, ttlLeftMs: ttlLeft });
    return __datasetCache;
  }
  const token = await getAccessToken();
  const records = await fetchDataset(token);
  // Map to minimal shape and dedupe by id to reduce memory
  const byId = new Map<string, ItemDTO>();
  for (const rec of records) {
    const mapped = mapRecordToItem(rec as Record<string, unknown>);
    if (!mapped) continue;
    if (!byId.has(mapped.id)) byId.set(mapped.id, mapped);
  }
  const items = Array.from(byId.values());
  console.log("[items] dataset cache REFRESH", { raw: records.length, items: items.length });
  // Compute a stable hash for ETag/versioning once per refresh
  const hasher = crypto.createHash("sha1");
  for (const it of items) {
    hasher.update(JSON.stringify({
      id: it.id,
      name: it.name,
      parent: it.parent,
      category: it.category,
      subcategory: it.subcategory,
      description: it.description,
      slowMovingPromo: it.slowMovingPromo,
      fiberVendor: it.fiberVendor,
      itemSubstitutes: it.itemSubstitutes,
    }));
  }
  const hash = hasher.digest("hex");
  __datasetCache = {
    items,
    hash,
    fetchedAt: now,
    expiresAt: now + getTTLms(),
  };
  return __datasetCache;
}

let __envLoggedOnce = false;
export const handleItems: RequestHandler = async (req, res) => {
  try {
    if (!__envLoggedOnce) {
      __envLoggedOnce = true;
      console.log("/api/items env", {
        DOMO_CLIENT_ID_set: Boolean(process.env.DOMO_CLIENT_ID),
        DOMO_CLIENT_SECRET_set: Boolean(process.env.DOMO_CLIENT_SECRET),
        DOMO_DATASET_ID_set: Boolean(process.env.DOMO_DATASET_ID),
      });
    }
    const limitParam = Number(
      req.query.limit ?? process.env.ITEMS_DEFAULT_LIMIT ?? 100,
    );
    const pageParam = Number(req.query.page ?? 1);
    const limit =
      Number.isFinite(limitParam) && limitParam > 0
        ? Math.floor(limitParam)
        : 100;
    const page = Number.isFinite(pageParam) && pageParam > 0 ? Math.floor(pageParam) : 1;

    const start = (page - 1) * limit;
    const end = start + limit;

    const { items: itemsAll, hash: datasetHash, fetchedAt } = await getDatasetCached();

    const q = String(req.query.q ?? "").trim().toLowerCase();
    function parseTokens(q: string): string[] {
      const re = /"([^"]+)"|(\S+)/g;
      const tokens: string[] = [];
      let m: RegExpExecArray | null;
      while ((m = re.exec(q))) {
        const t = (m[1] || m[2] || "").trim().toLowerCase();
        if (t) tokens.push(t);
      }
      return tokens;
    }
    const tokens = q ? parseTokens(q) : [];
    const categoryFilter = String(req.query.category ?? "").trim();
    const subFilter = String(req.query.sub ?? "").trim();
    const promoFilter = String(req.query.promo ?? "").trim().toLowerCase(); // "yes" | "no" | "all"
    const vendorFilter = String(req.query.vendor ?? "").trim();
    console.log("[items] request", { page, limit, hasQ: Boolean(q), categoryFilter, subFilter, promoFilter, vendorFilter });

    const catSet = new Set<string>();
    const subAllSet = new Set<string>();
    const subByCat = new Map<string, Set<string>>();
    const vendorByCat = new Map<string, Set<string>>();

    const matches: ItemDTO[] = [];

    for (const mapped of itemsAll) {
      // Collect global options across entire dataset
      if (mapped.category) catSet.add(mapped.category);
      if (mapped.subcategory) {
        subAllSet.add(mapped.subcategory);
        if (mapped.category) {
          if (!subByCat.has(mapped.category)) subByCat.set(mapped.category, new Set());
          subByCat.get(mapped.category)!.add(mapped.subcategory);
        }
      }
      if (mapped.fiberVendor && mapped.category) {
        if (!vendorByCat.has(mapped.category)) vendorByCat.set(mapped.category, new Set());
        vendorByCat.get(mapped.category)!.add(mapped.fiberVendor);
      }

      const catOk = !categoryFilter || categoryFilter === "all" || mapped.category === categoryFilter;
      const subOk = !subFilter || subFilter === "all" || mapped.subcategory === subFilter;
      const promoOk = !promoFilter || promoFilter === "all" || (promoFilter === "yes" ? mapped.slowMovingPromo : !mapped.slowMovingPromo);
      const vendorOk = !vendorFilter || (mapped.category === "500 - Cable & Wire" && mapped.fiberVendor === vendorFilter);
      const text = `${mapped.name} ${mapped.description} ${mapped.id} ${mapped.parent} ${mapped.category} ${mapped.subcategory} ${mapped.fiberVendor} ${mapped.itemSubstitutes || ""} ${(mapped.slowMovingPromo ? "yes" : "no")}`.toLowerCase();
      const qOk = tokens.length === 0 || tokens.every((t) => text.includes(t));
      if (catOk && subOk && promoOk && vendorOk && qOk) matches.push(mapped);
    }

    const total = matches.length;
    const items = matches.slice(start, end);

    const totalPages = Math.max(1, Math.ceil(total / limit));
    const categories = Array.from(catSet).sort();
    const subcategoriesAll = Array.from(subAllSet).sort();
    const subcategoriesByCategory = Object.fromEntries(
      Array.from(subByCat.entries()).map(([k, v]) => [k, Array.from(v).sort()]),
    );
    const fiberVendorsByCategory = Object.fromEntries(
      Array.from(vendorByCat.entries()).map(([k, v]) => [k, Array.from(v).sort()]),
    );

    const response: ItemsResponse = {
      items,
      page,
      limit,
      total,
      totalPages,
      categories,
      subcategoriesAll,
      subcategoriesByCategory,
      fiberVendorsByCategory,
    };

    // Build ETag based on dataset version + query params
    const etagSource = `${datasetHash}|${page}|${limit}|${q}|${categoryFilter}|${subFilter}|${promoFilter}|${vendorFilter}`;
    const etag = `W/"${crypto.createHash("sha1").update(etagSource).digest("hex")}"`;

    // Handle conditional request
    const ifNoneMatch = req.header("If-None-Match");
    res.set("ETag", etag);
    res.set("Cache-Control", process.env.ITEMS_CACHE_CONTROL ?? "public, max-age=60, stale-while-revalidate=300");
    res.set("Vary", "Accept, Accept-Encoding");
    res.set("X-Dataset-Fetched-At", String(fetchedAt));

    if (ifNoneMatch && ifNoneMatch === etag) {
      console.log("[items] 304 not modified");
      res.status(304).end();
      return;
    }

    // Prepare payload and compress if client accepts gzip
    const json = JSON.stringify(response);
    const acceptEnc = req.header("Accept-Encoding") || "";
    if (/\bgzip\b/.test(acceptEnc)) {
      await new Promise<void>((resolve, reject) => {
        zlib.gzip(Buffer.from(json), (err, buf) => {
          if (err) return reject(err);
          res.set("Content-Encoding", "gzip");
          res.type("application/json");
          res.send(buf);
          console.log("[items] 200 gzip", { page, limit, total, returned: items.length });
          resolve();
        });
      });
    } else {
      res.type("application/json").send(json);
      console.log("[items] 200", { page, limit, total, returned: items.length });
    }
  } catch (err: any) {
    console.error("/api/items error", { message: err?.message, stack: err?.stack });
    res.status(500).json({ error: String(err?.message || err) });
  }
};

export const handleItemById: RequestHandler = async (req, res) => {
  try {
    const id = String(req.params.id ?? "").trim();
    if (!id) {
      res.status(400).json({ error: "Missing id" });
      return;
    }

    const { items: itemsAll, hash: datasetHash, fetchedAt } = await getDatasetCached();
    const item = itemsAll.find((it) => it.id === id) || null;

    const etagSource = `${datasetHash}|${id}`;
    const etag = `W/"${crypto.createHash("sha1").update(etagSource).digest("hex")}"`;

    const ifNoneMatch = req.header("If-None-Match");
    res.set("ETag", etag);
    res.set("Cache-Control", process.env.ITEMS_CACHE_CONTROL ?? "public, max-age=60, stale-while-revalidate=300");
    res.set("Vary", "Accept, Accept-Encoding");
    res.set("X-Dataset-Fetched-At", String(fetchedAt));

    if (ifNoneMatch && ifNoneMatch === etag) {
      res.status(304).end();
      return;
    }

    if (!item) {
      res.status(404).json({ error: "Not found" });
      return;
    }

    const json = JSON.stringify(item);
    const acceptEnc = req.header("Accept-Encoding") || "";
    if (/\bgzip\b/.test(acceptEnc)) {
      zlib.gzip(Buffer.from(json), (err, buf) => {
        if (err) {
          console.error("/api/items/:id gzip error", err);
        }
        if (!res.headersSent) res.set("Content-Encoding", "gzip");
        res.type("application/json").send(err ? json : buf);
      });
    } else {
      res.type("application/json").send(json);
    }
  } catch (err: any) {
    console.error("/api/items/:id error", { message: err?.message, stack: err?.stack });
    res.status(500).json({ error: String(err?.message || err) });
  }
};

export const handleItemInsights: RequestHandler = async (req, res) => {
  try {
    const id = String(req.params.id ?? "").trim();
    if (!id) {
      res.status(400).json({ error: "Missing id" });
      return;
    }
    const { hash: datasetHash, fetchedAt } = await getDatasetCached();

    const payload: ItemInsights = {
      id,
      pricingRecommendations: [],
      priceHistory: [],
      purchaseOrders: [],
      leadTimes: [],
    };

    const etag = `W/"${crypto.createHash("sha1").update(`${datasetHash}|insights|${id}`).digest("hex")}"`;
    const ifNoneMatch = req.header("If-None-Match");
    res.set("ETag", etag);
    res.set("Cache-Control", process.env.ITEMS_CACHE_CONTROL ?? "public, max-age=60, stale-while-revalidate=300");
    res.set("Vary", "Accept, Accept-Encoding");
    res.set("X-Dataset-Fetched-At", String(fetchedAt));

    if (ifNoneMatch && ifNoneMatch === etag) {
      res.status(304).end();
      return;
    }

    const acceptEnc = req.header("Accept-Encoding") || "";
    const json = JSON.stringify(payload);
    if (/\bgzip\b/.test(acceptEnc)) {
      zlib.gzip(Buffer.from(json), (err, buf) => {
        if (err) return res.type("application/json").send(json);
        res.set("Content-Encoding", "gzip");
        res.type("application/json").send(buf);
      });
    } else {
      res.type("application/json").send(json);
    }
  } catch (err: any) {
    console.error("/api/items/:id/insights error", { message: err?.message, stack: err?.stack });
    res.status(500).json({ error: String(err?.message || err) });
  }
};

export const handleItemAvailability: RequestHandler = async (req, res) => {
  try {
    const id = String(req.params.id ?? "").trim();
    if (!id) {
      res.status(400).json({ error: "Missing id" });
      return;
    }
    const { hash: datasetHash, fetchedAt } = await getDatasetCached();
    const payload = { id, availability: [] };
    const etag = `W/"${crypto.createHash("sha1").update(`${datasetHash}|availability|${id}`).digest("hex")}"`;
    const ifNoneMatch = req.header("If-None-Match");
    res.set("ETag", etag);
    res.set("Cache-Control", process.env.ITEMS_CACHE_CONTROL ?? "public, max-age=60, stale-while-revalidate=300");
    res.set("Vary", "Accept, Accept-Encoding");
    res.set("X-Dataset-Fetched-At", String(fetchedAt));

    if (ifNoneMatch && ifNoneMatch === etag) {
      res.status(304).end();
      return;
    }

    const json = JSON.stringify(payload);
    const acceptEnc = req.header("Accept-Encoding") || "";
    if (/\bgzip\b/.test(acceptEnc)) {
      zlib.gzip(Buffer.from(json), (err, buf) => {
        if (err) return res.type("application/json").send(json);
        res.set("Content-Encoding", "gzip");
        res.type("application/json").send(buf);
      });
    } else {
      res.type("application/json").send(json);
    }
  } catch (err: any) {
    console.error("/api/items/:id/availability error", { message: err?.message, stack: err?.stack });
    res.status(500).json({ error: String(err?.message || err) });
  }
};

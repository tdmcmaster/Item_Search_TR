import type { RequestHandler } from "express";
import type { SalesRecord, SalesResponse } from "@shared/api";

const DOMO_BASE = process.env.DOMO_BASE_URL || "https://api.domo.com";
const SCOPE = process.env.DOMO_SCOPE || "data";

function normalizeKey(key: string) {
  return key
    .trim()
    .toLowerCase()
    .replace(/[\s_%.-]+/g, "");
}

function parseCSV(csv: string): Record<string, string>[] {
  const rows: string[][] = [];
  let i = 0;
  let field = "";
  let row: string[] = [];
  let inQuotes = false;
  while (i < csv.length) {
    const ch = csv[i];
    if (inQuotes) {
      if (ch === '"') {
        if (csv[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        } else {
          inQuotes = false;
          i++;
          continue;
        }
      } else {
        field += ch;
        i++;
        continue;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
        i++;
        continue;
      }
      if (ch === ",") {
        row.push(field);
        field = "";
        i++;
        continue;
      }
      if (ch === "\n") {
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
        i++;
        continue;
      }
      if (ch === "\r") {
        i++;
        continue;
      }
      field += ch;
      i++;
    }
  }
  row.push(field);
  rows.push(row);
  if (rows.length === 0) return [];
  const headers = rows[0];
  return rows
    .slice(1)
    .filter((r) => r.length && r.some((c) => c !== ""))
    .map((r) => {
      const obj: Record<string, string> = {};
      for (let j = 0; j < headers.length; j++) obj[headers[j]] = r[j] ?? "";
      return obj;
    });
}

async function getAccessToken(): Promise<string> {
  const clientId = process.env.DOMO_CLIENT_ID;
  const clientSecret = process.env.DOMO_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    const missing: string[] = [];
    if (!clientId) missing.push("DOMO_CLIENT_ID");
    if (!clientSecret) missing.push("DOMO_CLIENT_SECRET");
    throw new Error(
      `DOMO credentials not configured: missing ${missing.join(", ")}`,
    );
  }
  const creds = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    scope: SCOPE,
  });
  const res = await fetch(`${DOMO_BASE}/oauth/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${creds}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DOMO auth failed: ${res.status} ${t}`);
  }
  const json = (await res.json()) as { access_token: string };
  return json.access_token;
}

async function fetchDataset(
  token: string,
  datasetId: string,
): Promise<Record<string, unknown>[]> {
  const url = `${DOMO_BASE}/v1/datasets/${datasetId}/data?includeHeader=true&format=json`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DOMO data fetch failed: ${res.status} ${t}`);
  }
  const ctype = res.headers.get("content-type") || "";
  if (ctype.includes("application/json"))
    return (await res.json()) as Record<string, unknown>[];
  const text = await res.text();
  return parseCSV(text) as Record<string, unknown>[];
}

function toNumber(val: unknown): number {
  if (typeof val === "number") return val;
  const s = String(val ?? "")
    .replace(/[%$,]/g, "")
    .trim();
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

function parseDateFlexible(s: string): number | null {
  const t = Date.parse(s);
  if (!Number.isNaN(t)) return t;
  // Try MM/DD/YYYY or DD/MM/YYYY basic
  const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
  if (m) {
    const a = Number(m[1]);
    const b = Number(m[2]);
    const y = Number(m[3].length === 2 ? `20${m[3]}` : m[3]);
    // Assume MM/DD/YYYY first; fallback to DD/MM/YYYY if invalid
    const d1 = new Date(y, a - 1, b).getTime();
    if (!Number.isNaN(d1)) return d1;
    const d2 = new Date(y, b - 1, a).getTime();
    if (!Number.isNaN(d2)) return d2;
  }
  return null;
}

function extractAfterColon(s: string): string {
  const idx = s.indexOf(":");
  return idx >= 0 ? s.slice(idx + 1).trim() : s.trim();
}

function pickKey(
  nk: Record<string, string>,
  candidates: string[],
): string | null {
  for (const c of candidates) {
    const key = nk[normalizeKey(c)];
    if (key) return key;
  }
  return null;
}

function mapToSalesRecord(
  rec: Record<string, unknown>,
  nk: Record<string, string>,
): SalesRecord {
  const kDocument = pickKey(nk, [
    "documentnumber",
    "docnumber",
    "salesorder",
    "salesordernumber",
    "ordernumber",
    "orderid",
    "documentno",
  ]);
  const kDate = pickKey(nk, [
    "datecreated",
    "createddate",
    "date",
    "created",
    "orderdate",
  ]);
  const kName = pickKey(nk, [
    "name",
    "client",
    "customer",
    "customername",
    "account",
    "soldto",
    "billto",
  ]);
  const kSubMarket = pickKey(nk, [
    "submarket",
    "market",
    "region",
    "subregion",
  ]);
  const kQty = pickKey(nk, ["quantity", "qty", "orderqty", "orderedquantity"]);
  const kUnitPrice = pickKey(nk, [
    "unitprice",
    "price",
    "unit_rate",
    "unit",
    "unitamount",
    "salesprice",
  ]);
  const kEstUnitCost = pickKey(nk, [
    "estunitcost",
    "estimatedunitcost",
    "estcost",
    "unitcost",
    "cost",
  ]);
  const kEstGP = pickKey(nk, [
    "estgrossprofit%",
    "estgrossprofitpct",
    "estgrossprofitpercent",
    "estgp",
    "grossprofit%",
    "grossprofitpct",
  ]);
  const kMarkup = pickKey(nk, [
    "markup%",
    "markuppct",
    "markuppercent",
    "markup",
  ]);
  const kTerms = pickKey(nk, ["terms", "paymentterms", "netterms"]);

  const get = (k: string | null) => (k ? rec[k] : "");

  const dateRaw = String(get(kDate) ?? "").trim();
  const ts = dateRaw ? parseDateFlexible(dateRaw) : null;
  const dateCreated = ts ? new Date(ts).toISOString().slice(0, 10) : "";

  return {
    salesOrder: String(get(kDocument) ?? ""),
    dateCreated,
    client: String(get(kName) ?? ""),
    market: String(get(kSubMarket) ?? ""),
    quantity: toNumber(get(kQty)),
    unitPrice: toNumber(get(kUnitPrice)),
    estUnitCost: toNumber(get(kEstUnitCost)),
    estGrossProfitPct: toNumber(get(kEstGP)),
    markUpPct: toNumber(get(kMarkup)),
    terms: String(get(kTerms) ?? ""),
  };
}

export const handleSales: RequestHandler = async (req, res) => {
  try {
    const rawItem = String(req.query.item ?? "").trim();
    const itemFilter = rawItem ? extractAfterColon(rawItem) : "";
    const daysParam = Number(req.query.days ?? 90);
    const days =
      Number.isFinite(daysParam) && daysParam > 0 ? Math.floor(daysParam) : 90;
    const limitParam = Number(req.query.limit ?? 100);
    const pageParam = Number(req.query.page ?? 1);
    const limit =
      Number.isFinite(limitParam) && limitParam > 0
        ? Math.floor(limitParam)
        : 100;
    const page =
      Number.isFinite(pageParam) && pageParam > 0 ? Math.floor(pageParam) : 1;

    const datasetId = String(
      req.query.datasetId || process.env.DOMO_SALES_DATASET_ID || "",
    ).trim();
    if (!datasetId) {
      res
        .status(500)
        .json({
          error: "DOMO_SALES_DATASET_ID not set and no datasetId provided",
        });
      return;
    }

    const token = await getAccessToken();
    const records = await fetchDataset(token, datasetId);

    const now = Date.now();
    const cutoff = now - days * 24 * 60 * 60 * 1000;

    const results: SalesRecord[] = [];

    for (const r of records) {
      const keys = Object.keys(r);
      const nk = Object.fromEntries(
        keys.map((k) => [normalizeKey(k), k]),
      ) as Record<string, string>;

      // Identify item key if present
      const itemKey = pickKey(nk, [
        "item",
        "itemid",
        "itemnumber",
        "sku",
        "product",
        "productid",
        "productcode",
        "itemname",
      ]);
      const itemValue = itemKey ? String((r as any)[itemKey] ?? "").trim() : "";

      // Date filter
      const dateKey = pickKey(nk, [
        "datecreated",
        "createddate",
        "date",
        "created",
        "orderdate",
      ]);
      const dateRaw = dateKey ? String((r as any)[dateKey] ?? "").trim() : "";
      const ts = dateRaw ? parseDateFlexible(dateRaw) : null;
      if (!ts || ts < cutoff) continue;

      // Item filter if provided
      if (itemFilter) {
        const ok = itemValue
          ? itemValue.toLowerCase() === itemFilter.toLowerCase()
          : // fallback: match against any field if item column isn't present
            Object.values(r).some(
              (v) => String(v ?? "").toLowerCase() === itemFilter.toLowerCase(),
            );
        if (!ok) continue;
      }

      results.push(mapToSalesRecord(r as Record<string, unknown>, nk));
    }

    // sort newest first by dateCreated
    results.sort((a, b) =>
      a.dateCreated < b.dateCreated
        ? 1
        : a.dateCreated > b.dateCreated
          ? -1
          : 0,
    );

    const total = results.length;
    const start = (page - 1) * limit;
    const end = start + limit;
    const pageRecords = results.slice(start, end);

    const payload: SalesResponse = { records: pageRecords, total, page, limit };
    res.set("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
    res.json(payload);
  } catch (err: any) {
    console.error("/api/sales error", err?.message || err);
    res.status(500).json({ error: String(err?.message || err) });
  }
};
